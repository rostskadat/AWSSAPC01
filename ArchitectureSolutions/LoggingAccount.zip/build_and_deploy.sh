#!/bin/sh

sam build && \
    sam deploy --no-fail-on-empty-changeset --no-confirm-changeset --tags "PLATFORM=ARCHITECTURE_LABS"