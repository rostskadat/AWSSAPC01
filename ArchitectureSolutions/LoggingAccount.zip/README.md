# Kinesis / LoggingAccount

Log from several account into a logging Account using Kinesis Firehose and Log stream subscription filters. This is variant on:

*A CloudWatch Logs agent is installed on each of the EC2 instances running these IT applications. The company wants to aggregate all security events in a centralized AWS account dedicated to log storage. The centralized operations team at the company needs to perform near-real-time gathering and collating events across multiple AWS accounts.*

*Set up Kinesis Data Streams in the logging account and then subscribe the stream to CloudWatch Logs streams in each application AWS account via subscription filters. Configure an Amazon Kinesis Data Firehose delivery stream with the Data Streams as its source and persist the log data in an Amazon S3 bucket inside the logging AWS account* 


## Building

```shell
sam build 
sam deploy --no-fail-on-empty-changeset --no-confirm-changeset --tags "PLATFORM=ARCHITECTURE_LABS" 
``` 

## Testing

With SAM you can test your function locally:

```shell
sam local invoke --event events/events.json LoggingAccountFunction
```

## Cleanup

To delete the sample application that you created, use the AWS CLI. Assuming you used your project name for the stack name, you can run the following:

```shell
aws cloudformation delete-stack --stack-name SAPC01-LoggingAccount
```

## Details

*Author*: rostskadat
