#!/bin/sh

aws cloudformation delete-stack --stack-name SAPC01-LoggingAccount