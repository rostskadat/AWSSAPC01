#!/bin/bash

echo "------------------------- MOUNT"
mount
echo "------------------------- PS"
ps -eo args
echo "------------------------- YUM"
yum list installed

