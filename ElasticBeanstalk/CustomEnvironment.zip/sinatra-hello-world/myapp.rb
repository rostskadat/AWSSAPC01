require 'sinatra'
require "sinatra/reloader" if development?

after_reload do
    puts 'Application reloaded...'
end
configure :development do
    register Sinatra::Reloader
end

get '/' do
    "Hello World!"
end
    
get '/health' do
    'OK'
end
