# ElasticBeanstalk / CustomEnvironment

Showcase the use of a custom platform to create an ElasticBeanstalk environment for a non supported environement.

Reference [custom-platforms](https://docs.aws.amazon.com/elasticbeanstalk/latest/dg/custom-platforms.html#custom-platform-creating)

## Building

```shell
sam build 
sam deploy --no-fail-on-empty-changeset --no-confirm-changeset --tags "PLATFORM=ARCHITECTURE_LABS" 
``` 

## Testing

With SAM you can test your function locally:

```shell
sam local invoke --event events/events.json CustomEnvironmentFunction
```

## Cleanup

To delete the sample application that you created, use the AWS CLI. Assuming you used your project name for the stack name, you can run the following:

```shell
aws cloudformation delete-stack --stack-name SAPC01-CustomEnvironment
```

## Details

*Author*: rostskadat
